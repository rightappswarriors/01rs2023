<nav class="navbar navbar-expand-md navbar-dark bg-dark" style="background: linear-gradient(to bottom left, #228B22, #84bd82);padding: 1px 1px 1px 1px;">

  <a class="navbar-brand">
    <div class="row">
      <div class="col-xs-6">
        <img src="{{asset('ra-idlis/public/img/doh2.png')}}" style="max-height: 90px; padding-left: 20px;">
      </div>
      <div class="col-xs-6">
        <div class="republic">
          <p><small>Republic of the Philippines</small></p>    
          <p  style="margin-top: -10px;font-size: 18px;font-weight: 600">DEPARTMENT OF HEALTH</p>
          <p  style="margin-top: -10px;">Kagawaran ng Kalusugan</p>
          <p  style="margin-top: -10px;">ISO 9001:2008 CERTIFIED</p>
        </div>
      </div>
    </div>
  </a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

    <span class="navbar-toggler-icon"></span>

  </button>
</nav>