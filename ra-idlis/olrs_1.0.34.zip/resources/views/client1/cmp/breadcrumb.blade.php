<div class="container-fluid">
<nav aria-label="breadcrumb">
  <ol class="breadcrumb d-flex" id="bCBefCont"  style="background-color: transparent !important;padding: .75rem 3rem;">
  	<li class="breadcrumb-item active" id="__homeBread"><a href="{{asset('client1/home')}}" style="color: inherit; text-decoration: none;"><i class="fa fa-home"></i> Home</a></li>
  	<li class="breadcrumb-item active" id="__applyBread"><a href="{{asset('client1/apply')}}" style="color: inherit; text-decoration: none;"><i class="fa fa-file-text-o"></i> Application</a></li>
  	{{-- <li class="breadcrumb-item active" id="__paymentBread"><i class="fa fa-credit-card"></i> PAYMENT</li>
  	<li class="breadcrumb-item active" id="__paymentBread"><i class="fa fa-file-text"></i> EVALUATION</li>
  	<li class="breadcrumb-item active" id="__paymentBread"><i class="fa fa-file-text"></i> INSPECTION</li>
  	<li class="breadcrumb-item active" id="__issuanceBread"><i class="fa fa-print"></i> ISSUANCE</li> --}}
  </ol>
</nav>
</div>