<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CdrrHrRequirement extends Model
{
    protected $table = 'cdrrhrrequirements';
    protected $primaryKey = 'reqID';
}
