<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TableHistory extends Model
{
    protected $table = 'table_history';
    protected $primaryKey = 'table_hist_id';
}
