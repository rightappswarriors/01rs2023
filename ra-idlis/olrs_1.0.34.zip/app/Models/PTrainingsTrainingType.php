<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PTrainingsTrainingType extends Model
{
    protected $table = 'ptrainings_trainingtype';
    protected $primaryKey = 'ttid';
}
