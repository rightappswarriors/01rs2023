<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SurvRec extends Model
{
    protected $table = 'surv_rec';
    protected $primaryKey = 'rec_id';
}
