<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HFSRBannexb extends Model
{
    protected $table = 'hfsrbannexb';
}
