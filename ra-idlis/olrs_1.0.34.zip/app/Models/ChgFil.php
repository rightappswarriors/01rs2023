<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChgFil extends Model
{
    protected $table = 'chgfil';
}
