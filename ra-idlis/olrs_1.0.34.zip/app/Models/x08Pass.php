<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class x08Pass extends Model
{
    protected $table = 'x08_pass';
    protected $primaryKey = 'x08p_id';
}
