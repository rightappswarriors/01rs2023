<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AsmtH1 extends Model
{
    protected $table = 'asmt_h1';
    protected $primaryKey = 'asmtH1ID';
}
