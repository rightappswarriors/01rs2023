<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RadoholrstblHdr extends Model
{
    protected $table = 'radoholrstbl_hdr';
}
