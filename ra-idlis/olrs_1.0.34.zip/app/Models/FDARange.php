<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FDARange extends Model
{
    protected $table = 'fdarange';
}
