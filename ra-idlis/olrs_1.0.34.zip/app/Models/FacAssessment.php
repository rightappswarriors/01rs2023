<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FacAssessment extends Model
{
    protected $table = 'facassessment';
}
