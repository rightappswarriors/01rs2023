<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReqAst extends Model
{
    protected $table = 'req_ast';
    protected $primaryKey = 'rq_id';
}
