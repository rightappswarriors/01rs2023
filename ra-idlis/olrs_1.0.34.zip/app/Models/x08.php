<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class x08 extends Model
{
    protected $table = 'x08';
    protected $primaryKey = 'uid';
    public $incrementing = false;
    protected $keyType = 'string';
}
