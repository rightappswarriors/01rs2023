<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PTC extends Model
{
    protected $table = 'ptc';
}
