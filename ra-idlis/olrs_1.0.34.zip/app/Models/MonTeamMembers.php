<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MonTeamMembers extends Model
{
    protected $table = 'mon_team_members';
    protected $primaryKey = 'montmemberid';
}
