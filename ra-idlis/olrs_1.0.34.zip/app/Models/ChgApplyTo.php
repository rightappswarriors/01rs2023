<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChgApplyTo extends Model
{
    protected $table = 'chg_applyto';
    protected $primaryKey = 'applytoid';
}
