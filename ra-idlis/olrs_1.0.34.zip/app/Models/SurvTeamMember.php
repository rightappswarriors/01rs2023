<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SurvTeamMember extends Model
{
    protected $table = 'surv_team_members';
    protected $primaryKey = 'montmemberid';
}
