<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FunCapF extends Model
{
    protected $table = 'funcapf';
    protected $primaryKey = 'funcid';
}
