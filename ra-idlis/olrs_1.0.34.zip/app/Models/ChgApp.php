<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChgApp extends Model
{
    protected $table = 'chg_app';
    protected $primaryKey = 'chgapp_id';
}
