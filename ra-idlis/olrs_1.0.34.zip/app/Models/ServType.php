<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServType extends Model
{
    protected $table = 'serv_type';
    protected $primaryKey = 'servtype_id';
}
