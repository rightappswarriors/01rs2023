<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class XrayFacilityLevel extends Model
{
    protected $table = 'xrayfacilitylevel';
    protected $primaryKey = 'codelevel';
}
