<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FDAXrayServ extends Model
{
    protected $table = 'fda_xrayserv';
    protected $primaryKey = 'servid';
}
