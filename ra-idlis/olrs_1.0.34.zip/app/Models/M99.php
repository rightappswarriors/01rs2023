<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class M99 extends Model
{
    protected $table = 'm99';
}
