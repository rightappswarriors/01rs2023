<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MonTeam extends Model
{
    protected $table = 'mon_team';
    protected $primaryKey = 'montid';
}
