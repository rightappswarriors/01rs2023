<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HFACICustomOne extends Model
{
    protected $table = 'hfaci_custom_one';
    protected $primaryKey = 'hcus_id';
}
