<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RadoholrstblCtnt extends Model
{
    protected $table = 'radoholrstbl_ctnt';
}
