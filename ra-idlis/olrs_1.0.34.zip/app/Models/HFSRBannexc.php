<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HFSRBannexc extends Model
{
    protected $table = 'hfsrbannexc';
}
