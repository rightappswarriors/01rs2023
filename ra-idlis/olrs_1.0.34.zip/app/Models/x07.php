<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class x07 extends Model
{
    protected $table = 'x07';
    protected $primaryKey = 'grp_id';
    public $incrementing = false;
    protected $keyType = 'string';
}
