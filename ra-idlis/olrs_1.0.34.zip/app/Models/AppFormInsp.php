<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppFormInsp extends Model
{
    protected $table = 'appform_insp';
    protected $primaryKey = 'apinsp_id';
}
