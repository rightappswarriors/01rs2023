<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChgFaci extends Model
{
    protected $table = 'chg_faci';
    protected $primaryKey = 'applylocid';
}
