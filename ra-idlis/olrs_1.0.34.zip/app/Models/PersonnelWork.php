<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PersonnelWork extends Model
{
    protected $table = 'personnelwork';
    protected $primaryKey = 'pworkid';
}
