<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppTeam extends Model
{
    protected $table = 'app_team';
    protected $primaryKey = 'apptid';
}
