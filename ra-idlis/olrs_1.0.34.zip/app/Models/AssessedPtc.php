<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssessedPtc extends Model
{
    protected $table = 'assessedptc';
    protected $primaryKey = 'assessedID';
}
