<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class x05 extends Model
{
    protected $table = 'x05';
    protected $primaryKey = 'mod_id';
    public $incrementing = false;
    protected $keyType = 'string';
}
