<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PTraining extends Model
{
    protected $table = 'ptrainings';
    protected $primaryKey = 'ptid';
}
