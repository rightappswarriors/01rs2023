<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FacMode extends Model
{
    protected $table = 'facmode';
    protected $primaryKey = 'facmid';
}
