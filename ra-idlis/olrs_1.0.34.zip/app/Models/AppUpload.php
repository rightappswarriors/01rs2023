<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppUpload extends Model
{
    protected $table = 'app_upload';
    protected $primaryKey = 'apup_id';
}
