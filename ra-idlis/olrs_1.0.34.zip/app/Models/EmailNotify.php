<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmailNotify extends Model
{
    protected $table = 'emailnotify';
    protected $primaryKey = 'enid';
}
