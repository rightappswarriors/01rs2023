<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TechnicalFindingsHist extends Model
{
    protected $table = 'technicalfindingshist';
    protected $primaryKey = 'transid';
}
