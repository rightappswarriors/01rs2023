<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReAssessHist extends Model
{
    protected $table = 'reassess_hist';
    protected $primaryKey = 'reassess_histid';
}
