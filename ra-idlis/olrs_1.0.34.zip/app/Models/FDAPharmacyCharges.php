<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FDAPharmacyCharges extends Model
{
    protected $table = 'fda_pharmacycharges';
    protected $primaryKey = 'chargeID';
}
