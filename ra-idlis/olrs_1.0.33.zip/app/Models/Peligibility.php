<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Peligibility extends Model
{
    protected $table = 'peligibility';
    protected $primaryKey = 'peid';
}