<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssessmentRecommendation extends Model
{
    protected $table = 'assessmentrecommendation';
    protected $primaryKey = 'reco';
}
