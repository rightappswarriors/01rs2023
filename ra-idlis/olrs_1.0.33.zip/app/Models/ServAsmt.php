<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServAsmt extends Model
{
    protected $table = 'serv_asmt';
    protected $primaryKey = 'srvasmt_id';
}
