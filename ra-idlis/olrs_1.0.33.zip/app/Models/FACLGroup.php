<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FACLGroup extends Model {
    protected $table = 'facl_grp';
}
