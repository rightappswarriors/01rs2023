<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FDAChgFil extends Model
{
    protected $table = 'fda_chgfil';
    protected $primaryKey = 'fda_chgfilid';
}
