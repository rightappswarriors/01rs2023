<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CdrrHrXrayServCat extends Model
{
    protected $table = 'cdrrhrxrayservcat';
    protected $primaryKey = 'teamid';
}
