<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServChg extends Model
{
    protected $table = 'serv_chg';
}
