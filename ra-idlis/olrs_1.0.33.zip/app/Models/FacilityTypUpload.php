<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FacilityTypUpload extends Model
{
    protected $table = 'facilitytypupload';
    protected $primaryKey = 'facilitytypUploadid';
}
