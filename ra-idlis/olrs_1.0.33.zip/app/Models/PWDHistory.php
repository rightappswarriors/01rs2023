<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PWDHistory extends Model
{
    protected $table = 'pwdhistory';
    protected $primaryKey = 'ID';
}
