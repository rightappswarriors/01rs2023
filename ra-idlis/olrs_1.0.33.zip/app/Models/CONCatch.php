<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CONCatch extends Model
{
    protected $table = 'con_catch';
}
