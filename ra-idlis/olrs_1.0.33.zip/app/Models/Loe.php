<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Loe extends Model
{
    protected $table = 'loe';
    protected $primaryKey = 'loeid';
}
