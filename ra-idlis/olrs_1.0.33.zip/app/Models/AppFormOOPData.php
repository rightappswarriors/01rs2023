<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppFormOOPData extends Model
{
    protected $table = 'appform_oopdata';
    protected $primaryKey = 'appfoop_id';
}
