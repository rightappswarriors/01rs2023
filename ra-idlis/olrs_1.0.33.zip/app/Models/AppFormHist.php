<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppFormHist extends Model
{
    protected $table = 'appform_hist';
    protected $primaryKey = 'appformhist';
}
