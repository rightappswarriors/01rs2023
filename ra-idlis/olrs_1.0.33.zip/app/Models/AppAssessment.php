<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppAssessment extends Model
{
    protected $table = 'app_assessment';
    protected $primaryKey = 'app_assess_id';
}
