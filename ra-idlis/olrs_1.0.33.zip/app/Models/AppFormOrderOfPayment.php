<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppFormOrderOfPayment extends Model
{
    protected $table = 'appform_orderofpayment';
    protected $primaryKey = 'appop_id';
}
