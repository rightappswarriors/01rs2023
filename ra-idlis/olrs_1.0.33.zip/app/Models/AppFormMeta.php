<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppFormMeta extends Model
{
    //no primary key set in the database
}
