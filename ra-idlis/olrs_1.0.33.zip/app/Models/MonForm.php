<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MonForm extends Model
{
    protected $table = 'mon_form';
    protected $primaryKey = 'monid';
}
