<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Prepart extends Model
{
    protected $table = 'prepart';
    protected $primaryKey = 'partid';
}
