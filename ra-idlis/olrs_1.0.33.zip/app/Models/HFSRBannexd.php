<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HFSRBannexd extends Model
{
    protected $table = 'hfsrbannexd';
}
