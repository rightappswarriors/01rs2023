<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class x06 extends Model
{
    protected $table = 'x06';
    protected $primaryKey = 'x06_id';
}
