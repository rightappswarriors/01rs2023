<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RegionTransfer extends Model
{
    protected $table = 'regiontransfer';
    protected $primaryKey = 'transferid';
}
