<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HFSRBannexa extends Model
{
    protected $table = 'hfsrbannexa';
}
