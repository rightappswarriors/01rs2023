<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FDAMonitoringFiles extends Model
{
    protected $table = 'fdamonitoringfiles';
    protected $primaryKey = 'fdaFilesID';
}
