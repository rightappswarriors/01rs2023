<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CONEvalSave extends Model
{
    protected $table = 'con_evalsave';
}
