<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CONCatchment extends Model {
    protected $table = 'con_catch';
}