<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CityMuni extends Model
{
    protected $table = 'city_muni';
}
