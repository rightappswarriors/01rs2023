<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FacilityRequirement extends Model
{
    protected $table = 'facility_requirements';
    protected $primaryKey = 'fr_id';
}
