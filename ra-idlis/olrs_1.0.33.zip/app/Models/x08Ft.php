<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class x08Ft extends Model
{
    protected $table = 'x08_ft';
    protected $primaryKey = 'id';
}
