<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NovIssuedS extends Model
{
    protected $table = 'nov_issued_s';
    protected $primaryKey = 'novid';
}
