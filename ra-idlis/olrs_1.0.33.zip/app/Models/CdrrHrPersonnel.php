<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CdrrHrPersonnel extends Model
{
    protected $table = 'cdrrhrpersonnel';
}
