<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssessmentRecommendationHistory extends Model
{
    protected $table = 'assessmentrecommendationhistory';
    protected $primaryKey = 'recohistid';
}
