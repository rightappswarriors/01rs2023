<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CdrrHrOtherAttachment extends Model
{
    protected $table = 'cdrrhrotherattachment';
}
