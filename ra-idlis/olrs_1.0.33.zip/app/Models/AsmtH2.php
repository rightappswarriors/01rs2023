<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AsmtH2 extends Model
{
    protected $table = 'asmt_h2';
    protected $primaryKey = 'asmtH2ID';
}
