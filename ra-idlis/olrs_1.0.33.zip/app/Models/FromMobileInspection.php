<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FromMobileInspection extends Model
{
    protected $table = 'frommobileinspection';
    protected $primaryKey = 'inspectID';
}
