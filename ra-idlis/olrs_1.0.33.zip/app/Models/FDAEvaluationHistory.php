<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FDAEvaluationHistory extends Model
{
    protected $table = 'fdaevaluationhistory';
    protected $primaryKey = 'fdaevaluationhistoryID';
}
