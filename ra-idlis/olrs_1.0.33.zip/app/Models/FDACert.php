<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FDACert extends Model
{
    protected $table = 'fdacert';
    protected $primaryKey = 'certid';
}
