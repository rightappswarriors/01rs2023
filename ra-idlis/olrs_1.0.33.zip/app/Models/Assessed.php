<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Assessed extends Model
{
    protected $table = 'assessed';
    protected $primaryKey = 'assessedID';
}
