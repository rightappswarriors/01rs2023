<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CdrrAttachment extends Model
{
    protected $table = 'cdrrattachment';
}
