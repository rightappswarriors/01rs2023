<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AsmtH3 extends Model
{
    protected $table = 'asmt_h3';
    protected $primaryKey = 'asmtH3ID';
}
