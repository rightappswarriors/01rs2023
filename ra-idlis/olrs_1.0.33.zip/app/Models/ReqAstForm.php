<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReqAstForm extends Model
{
    protected $table = 'req_ast_form';
    protected $primaryKey = 'ref_no';
}
