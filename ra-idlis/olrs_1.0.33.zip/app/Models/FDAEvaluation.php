<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FDAEvaluation extends Model
{
    protected $table = 'fdaevaluation';
    protected $primaryKey = 'evalid';
}
