<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HFSRBannexh extends Model
{
    protected $table = 'hfsrbannexh';
}
