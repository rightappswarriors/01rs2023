<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class M04 extends Model
{
    protected $table = 'm04';
    protected $primaryKey = 'm04ID';
}
