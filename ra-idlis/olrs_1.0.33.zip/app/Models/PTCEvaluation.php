<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PTCEvaluation extends Model
{
    protected $table = 'ptc_evaluation';
    protected $primaryKey = 'app_eval_id';
}
