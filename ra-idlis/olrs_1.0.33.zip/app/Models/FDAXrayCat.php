<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FDAXrayCat extends Model
{
    protected $table = 'fda_xraycat';
    protected $primaryKey = 'catid';
}
