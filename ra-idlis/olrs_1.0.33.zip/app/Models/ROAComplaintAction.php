<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ROAComplaintAction extends Model
{
    protected $table = 'roacomplaintactions';
}
