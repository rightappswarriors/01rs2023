<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ComplaintsForm extends Model
{
    protected $table = 'complaints_form';
    protected $primaryKey = 'ref_no';
}
