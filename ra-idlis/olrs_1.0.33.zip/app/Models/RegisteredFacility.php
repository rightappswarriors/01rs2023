`<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RegisteredFacility extends Model
{
    protected $table        = 'registered_facility';
    protected $primaryKey   = 'regfac_id';
}
