<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HFSRBannexi extends Model
{
    protected $table = 'hfsrbannexi';
}
