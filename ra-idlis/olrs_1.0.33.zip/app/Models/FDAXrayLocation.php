<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FDAXrayLocation extends Model
{
    protected $table = 'fda_xraylocation';
    protected $primaryKey = 'locid';
}
