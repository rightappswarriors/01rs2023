<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Nov extends Model
{
    protected $table = 'nov';
    protected $primaryKey = 'novid_directions';
}
