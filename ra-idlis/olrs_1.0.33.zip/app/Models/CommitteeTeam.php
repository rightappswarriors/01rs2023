<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CommitteeTeam extends Model
{
    protected $table = 'committee_team';
    protected $primaryKey = 'committe';
}
