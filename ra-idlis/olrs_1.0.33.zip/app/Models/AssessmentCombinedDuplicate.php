<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssessmentCombinedDuplicate extends Model
{
    protected $table = 'assessmentcombinedduplicate';
    protected $primaryKey = 'dupID';
}
