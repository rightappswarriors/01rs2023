<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChgLoc extends Model
{
    protected $table = 'chg_loc';
}
