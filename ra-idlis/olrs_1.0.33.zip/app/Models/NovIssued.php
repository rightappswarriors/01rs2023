<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NovIssued extends Model
{
    protected $table = 'nov_issued';
    protected $primaryKey = 'novid';
}
