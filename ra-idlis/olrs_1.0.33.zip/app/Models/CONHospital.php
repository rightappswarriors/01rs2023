<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CONHospital extends Model {
    protected $table = 'con_hospital';
}
