<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HFERCEvaluation extends Model
{
    protected $table = 'hferc_evaluation';
    protected $primaryKey = 'hfercEvalId';
}
