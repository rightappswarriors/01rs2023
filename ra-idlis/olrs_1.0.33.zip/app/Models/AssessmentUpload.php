<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssessmentUpload extends Model
{
    protected $table = 'assessment_upload';
    protected $primaryKey = 'upload_id';
}
