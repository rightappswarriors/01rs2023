<nav aria-label="breadcrumb">
  <ol class="breadcrumb d-flex justify-content-center" id="bCBefCont">
  	<li class="breadcrumb-item active" id="__homeBread"><i class="fa fa-home dispLater"></i> HOME</li>
  	<li class="breadcrumb-item active" id="__applyBread"><i class="fa fa-file-word-o dispLater"></i> APPLY</li>
  	<li class="breadcrumb-item active" id="__paymentBread"><i class="fa fa-credit-card dispLater"></i> PAYMENT</li>
  	<li class="breadcrumb-item active" id="__evaluationBread"><i class="fa fa-file-text-o dispLater"></i> EVALUATION</li>
  	<li class="breadcrumb-item active" id="__inspectionBread"><i class="fa fa-file-text dispLater"></i> INSPECTION</li>
  	<li class="breadcrumb-item active" id="__issuanceBread"><i class="fa fa-print dispLater"></i> ISSUANCE</li>
  </ol>
</nav>